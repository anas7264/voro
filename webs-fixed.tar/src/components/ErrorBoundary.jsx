import React from "react";
import { AlertCircle, RefreshCw } from "lucide-react";

// Proper React Class-Based Error Boundary
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Error caught by boundary:", error, errorInfo);
    this.setState({
      error,
      errorInfo
    });
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#080B14] flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0A0C14] border border-red-500/20 rounded-2xl p-8 shadow-2xl">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-red-500/10 rounded-lg flex-shrink-0">
                <AlertCircle className="text-red-400" size={24} />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold text-red-400 mb-2">Something went wrong</h2>
                <p className="text-gray-400 text-sm mb-4">
                  {this.state.error?.message || "An unexpected error occurred"}
                </p>
                {process.env.NODE_ENV === "development" && this.state.errorInfo && (
                  <details className="mb-4 p-3 bg-black/40 rounded text-xs text-gray-500 max-h-48 overflow-auto font-mono">
                    <summary className="cursor-pointer mb-2 text-gray-400">Stack trace</summary>
                    {this.state.errorInfo.componentStack}
                  </details>
                )}
                <button
                  onClick={this.handleReset}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-lg transition-colors"
                >
                  <RefreshCw size={18} />
                  Try Again
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
