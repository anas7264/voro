import { useContext } from "react";
import { NotificationContext } from "../context/NotificationContext";

export const useNotifications = () => {
  const context = useContext(NotificationContext);

  if (!context) {
    throw new Error("useNotifications must be used within NotificationProvider");
  }

  return context;
};

export default useNotifications;
