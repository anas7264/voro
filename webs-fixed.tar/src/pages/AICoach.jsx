import React, { useEffect, useState, useCallback } from 'react';
import { Send, Loader, AlertCircle, Zap } from 'lucide-react';
import Button from '@/components/Button';
import Card from '@/components/Card';
import Input from '@/components/Input';
import { useStorage } from '@/hooks/useStorage';
import { useApp } from '@/hooks/useAppContext';
import { useAI } from '@/hooks/useAI';

const AICoach = () => {
  const { getStorage, setStorage } = useStorage();
  const { user } = useApp();
  const { chat, loading: aiLoading, error: aiError } = useAI();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [hasApiKey, setHasApiKey] = useState(!!import.meta.env.VITE_CLAUDE_API_KEY);

  const quickPrompts = [
    'What should I eat today?',
    'Analyze my week',
    'Suggest tomorrow\'s workout',
    'Am I on track?',
    'Explain my macros',
    'Motivate me!',
  ];

  useEffect(() => {
    document.title = 'VORO | AI Coach';
    const saved = getStorage('voro_chat_history') || [];
    setMessages(saved);
  }, [getStorage]);

  const handleSendMessage = useCallback(async (text = input) => {
    if (!text.trim()) return;

    const userMessage = { role: 'user', content: text, timestamp: new Date().toISOString() };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput('');
    setLoading(true);

    try {
      if (hasApiKey) {
        // Use real API
        const response = await chat(text, updatedMessages.slice(0, -1));
        const aiResponse = {
          role: 'assistant',
          content: response?.content || 'Unable to generate response. Please try again.',
          timestamp: new Date().toISOString(),
        };
        const finalMessages = [...updatedMessages, aiResponse];
        setMessages(finalMessages);
        setStorage('voro_chat_history', finalMessages);
      } else {
        // Fallback: mock response with notification
        setTimeout(() => {
          const aiResponse = {
            role: 'assistant',
            content: generateFallbackResponse(text),
            timestamp: new Date().toISOString(),
          };
          const finalMessages = [...updatedMessages, aiResponse];
          setMessages(finalMessages);
          setStorage('voro_chat_history', finalMessages);
        }, 500);
      }
    } catch (err) {
      console.error('AI Chat error:', err);
      // Fallback on error
      const errorResponse = {
        role: 'assistant',
        content: 'I encountered an error processing your request. Please try again or check your API configuration.',
        timestamp: new Date().toISOString(),
      };
      const finalMessages = [...updatedMessages, errorResponse];
      setMessages(finalMessages);
    } finally {
      setLoading(false);
    }
  }, [input, messages, chat, hasApiKey, getStorage, setStorage]);

  const generateFallbackResponse = (userInput) => {
    const responses = {
      'what should i eat': `Based on your goals, I'd recommend a protein-rich meal. Try grilled chicken (150g) with brown rice and roasted vegetables. That's about 600 kcal with 45g protein.`,
      'analyze my week': `Great week! You hit your calorie goal 5/7 days, averaged 165g protein, and trained 4 times. Keep up the consistency!`,
      'motivate': `You're crushing it! Your training streak is strong and you've logged every meal. This consistency compounds over time!`,
      'on track': `Yes! You're tracking perfectly. At this rate, you'll hit your goal in approximately 12 weeks. Stay focused!`,
      'macros': `Your current macros: Protein 1.8g/kg (excellent), Carbs 45% calories (good), Fat 30% calories (optimal). Well balanced!`,
      'workout': `Tomorrow I'd suggest: Chest & Triceps - Bench Press 4×6, Incline DB 3×8, Cable Flies 3×10, Dips 3×8, plus 20min cardio.`,
    };

    for (const [key, value] of Object.entries(responses)) {
      if (userInput.toLowerCase().includes(key)) {
        return value;
      }
    }

    return `I'm here to help! Ask me about your nutrition, training, goals, or progress. Note: For advanced AI features, please configure your API key.`;
  };

  return (
    <div className="min-h-screen bg-[#080B14] text-[#F0F4FF] pb-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <header className="mb-12">
          <div className="flex items-center gap-3 text-voro-primary mb-4">
            <Zap size={18} />
            <span className="text-[0.6rem] font-black uppercase tracking-[0.3em]">Neural Synthesis</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-serif italic font-medium text-white tracking-tight">
            AI <span className="text-voro-primary not-italic font-bold">Coach</span>
          </h1>
          {!hasApiKey && (
            <div className="mt-4 flex items-start gap-3 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl">
              <AlertCircle size={18} className="text-amber-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-amber-300">API key not configured. Using fallback responses. For full AI capabilities, configure VITE_CLAUDE_API_KEY in your environment.</p>
            </div>
          )}
        </header>

        {/* Chat Area */}
        <div className="bg-[#0A0C14] border border-white/5 rounded-[2.5rem] p-8 flex flex-col h-[600px] shadow-2xl">
          <div className="flex-1 overflow-y-auto mb-6 space-y-4 no-scrollbar">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <div className="text-6xl mb-4">🤖</div>
                <h2 className="text-2xl font-bold text-white mb-2">Welcome to VORO AI Coach</h2>
                <p className="text-gray-400 mb-8 max-w-md">I'm your personal AI fitness and nutrition coach. Ask me anything about your goals, progress, and training.</p>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 w-full">
                  {quickPrompts.map((prompt, idx) => (
                    <Button
                      key={idx}
                      variant="outline"
                      size="sm"
                      onClick={() => handleSendMessage(prompt)}
                      disabled={loading}
                      className="text-xs text-left h-auto py-3 px-4"
                    >
                      {prompt}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                  msg.role === 'user'
                    ? 'bg-voro-primary text-white'
                    : 'bg-white/5 border border-white/10 text-gray-300'
                }`}>
                  <p className="text-sm leading-relaxed">{msg.content}</p>
                  <span className="text-xs opacity-60 mt-2 block">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex justify-start">
                <div className="bg-white/5 border border-white/10 px-4 py-3 rounded-2xl">
                  <div className="flex items-center gap-2">
                    <Loader size={16} className="animate-spin text-voro-primary" />
                    <span className="text-sm text-gray-400">Coach is thinking...</span>
                  </div>
                </div>
              </div>
            )}

            {aiError && (
              <div className="flex justify-start">
                <div className="bg-red-500/10 border border-red-500/20 px-4 py-3 rounded-2xl">
                  <p className="text-sm text-red-300">Error: {aiError}</p>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="flex gap-3 pt-6 border-t border-white/5">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !loading && handleSendMessage()}
              placeholder="Ask me anything..."
              disabled={loading}
              className="flex-1"
            />
            <Button
              onClick={() => handleSendMessage()}
              disabled={loading || !input.trim()}
              className="px-6 flex items-center gap-2"
            >
              <Send size={16} />
              <span className="hidden sm:inline">Send</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AICoach;
